<?php include("auth_session.php"); ?>
<?php

	 include("header.php");
	 include("connection.php");
	 
?>



        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Change Password</h1>
                    </div>
                </div>
            </div>
                </div>

        <div class="content mt-3">
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <form name="form1" action="" method="post">
                            <div class="card-body">
                                <!-- Credit Card -->
                                
                                <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Change Password</strong></div>
                            <div class="card-body card-block">
                                <div class="form-group"><label for="company" class=" form-control-label">Old Password</label>
								<input type="text" name="opwd" placeholder="Enter Old Passowrd" class="form-control"></div>
                                    <div class="form-group"><label for="vat" class=" form-control-label">New Passowrd</label><input type="text" name="npwd" placeholder="Enter New Passowrd" class="form-control"></div>
                                        

                                        <div class="form-group">
                                        <input type="submit" name="submit" class="btn btn-success" value="Change Password">
                                        </div>

                                                </div>
                                           </div>
                           </div>

                            
                        </form>



                        </div> <!-- .card -->

                    </div>
                    <!--/.col-->

                
                
                
                </div>
            </div><!-- .animated -->
                                    </div><!-- .content -->

  <?php
if(isset($_POST['submit']))
{
 $oldpass=($_POST['opwd']);
 $adm_name=$_SESSION['username'];
 //$_SESSION['username']=$_POST['username'];
 $newpassword=($_POST['npwd']);
	$sql=mysqli_query($link,"SELECT password FROM admin where password='$oldpass' && username='$adm_name'");
	$num=mysqli_fetch_array($sql);
	if($num>0)
{
 $link=mysqli_query($link,"update admin set password='$newpassword' where username='$adm_name'");
	echo"<script>alert('Passowrd Changed Successfully!!!!');</script>";
}
else
{
echo"<script>alert('Old Passowrd Not match');</script>";
}
}
?>




        <?php
         include("footer.php");
         ?>
 