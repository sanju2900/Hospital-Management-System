<?php
include("auth_session.php");
include "header.php";
include "connection.php";
?>

<h1>Help and Support</h1>
<!--
<iframe src="https://dashboard.tawk.to/login" style="width:100%;height:100vh;border:1px solid grey;" frameborder="0"></iframe>
-->

<iframe src="https://dashboard.tawk.to/#/chat/60c4a5fe65b7290ac63598b0" style="width:100%;height:100vh;border:1px solid grey;" frameborder="0"></iframe>


<?php
include "footer.php";

?>