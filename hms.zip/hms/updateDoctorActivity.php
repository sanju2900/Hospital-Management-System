<?php
include "auth_session1.php";
//include "header2.php";
include "connection.php";

$id=$_POST["id"];
$status=$_POST["activity"];

$sql="UPDATE `doctor` SET `activity`='$status' WHERE `id`=$id";
$result=mysqli_query($link, $sql);
if($result){
    echo json_encode("success");
}else{
    echo json_encode("Query exicution failed");
}


?>