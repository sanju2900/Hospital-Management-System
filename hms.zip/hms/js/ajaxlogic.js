function updateDoctorActivity(status, id){
    if(status=="checked"){
       
        invokeUpdateActivity("off", id);
    }else{
        invokeUpdateActivity("on", id);
    }
};



function invokeUpdateActivity(st, did){
    $.ajax({
        url: "updateDoctorActivity.php",
        cache: false,
        data:{
            id:did,
            activity:st,
        },
        type: 'POST',
        success: function(dataResult) {
            res = JSON.parse(dataResult);
            if(res=="success"){
                alert("Activity Updated Successfully");
                window.location="applist1.php";
            }else{
                alert("Activity not updated due to error");
            }
        }
    });
}




function pushNotification() {

    var t = document.getElementById("PUSH_title").value;
    var m = document.getElementById("PUSH_message").value;
    var url = document.getElementById("PUSH_url").value;
    var banner ="";

    if (t.length > 5 && m.length > 10) {
        callAjaxOnesignal(t, m, banner, url);
        // alert('banner :' + banner);

    } else {
        alert("Minimum Chars Rule \n Title length: 5 \n Message:10 \n Banner: Required  ");
    }


}


function uploadPushBanner() {
    const ref = firebase.storage().ref('onesignal_banner');
    const file = document.querySelector("#PUSH_banner").files[0];
    const name = +new Date() + "-" + file.name;
    const metadata = {
        contentType: file.type
    };
    const task = ref.child(name).put(file, metadata);
    task
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then(url => {
            alert("Banner Uploaded");
            $("#bannerarea").append("<input type='text' id='pushbanner' value='" + url + "' hidden />");
        }).catch(console.error);

}


function callAjaxOnesignal(title, message, ban, u) {
    $.ajax({
        url: "one_signal.php",
        type: "POST",
        cache: false,
        data: {
            action: "onesignal",
            title: title,
            message: message,
            banner: ban,
            url: u,
        },
        success: function(dataResult) {
            alert("PUSH Notification Sent Successfully");
        }
    });
}