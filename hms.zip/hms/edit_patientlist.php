 
   <?php
   include("auth_session1.php");
         include("header2.php");
         include("connection.php");

        $id=$_GET["id"];
         $res=mysqli_query($link,"select * from patient where id=$id");
         while($row=mysqli_fetch_array($res))
         {
             $name=$row["name"];
             $age=$row["age"];
             $address=$row["address"];
             $phone=$row["phone"];
             $guardian=$row["guardian_name"];
         }

    ?>



        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Update Patient</h1>
                    </div>
                </div>
            </div>
                </div>

        <div class="content mt-3">
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <form name="form1" action="" method="post">
                            <div class="card-body">
                                <!-- Credit Card -->
                                
                                <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Update Patient</strong></div>
                            <div class="card-body card-block">
                                <div class="form-group"><label for="company" class=" form-control-label">Name</label><input type="text" name="name" value="<?php echo $name;?>" placeholder="Name" class="form-control"></div>
                                    <div class="form-group"><label for="vat" class=" form-control-label">Age</label><input type="number" name="age" value="<?php echo $age;?>" placeholder="Age" class="form-control"></div>
                                    <div class="form-group"><label for="street" class=" form-control-label">Address</label><input type="text" name="address" value="<?php echo $address;?>" placeholder="Address" class="form-control"></div>
                                        <div class="form-group"><label for="street" class=" form-control-label">Phone</label><input type="number" name="phone" value="<?php echo $phone;?>" placeholder="Phone" class="form-control"></div>
                                            <div class="form-group"><label for="street" class=" form-control-label">Guardian Name</label><input type="text" name="guardian_name" value="<?php echo $guardian;?>" placeholder="guardian_name" class="form-control"></div>


                                        <div class="form-group">
                                        <input type="submit" name="submit1" class="btn btn-success" value="Update Patient">
                                        </div>

                                         </div>
                                 </div>
                           </div>

                            
                    </div>
                    </form>



                        </div> <!-- .card -->

                    </div>
                    <!--/.col-->

                
                
                
                </div>
                                        </div><!-- .animated -->
                                    </div><!-- .content -->

  <?php
if(isset($_POST['submit1']))
{
    mysqli_query($link,"update patient set name='$_POST[name]',age='$_POST[age]',address='$_POST[address]',phone='$_POST[phone]',guardian_name='$_POST[guardian_name]' where id=$id") or die(mysqli_error($link));
    ?>
    <script type="text/javascript">
     
      window.location="patientlist.php";
    </script>
    <?php

}
?>




        <?php
         include("footer.php");
         ?>
 