<?php
include("auth_session.php");
include "header.php";
include "connection.php";
?>
<?php 
// for nodification
if(isset($_GET['id']))
{
    $main_id = $_GET['id'];
    $sql_update = mysqli_query($link,"UPDATE patient_appointments SET status=1 WHERE id='$main_id'");
}

?>
  
  <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><b><i>Welcome!!! To Appointment List</i></b></h1>
                    </div>
                </div>
            </div>
         <!--  <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Dashboard</a></li>
                            <li><a href="#">Table</a></li>
                            <li class="active">Data table</li>
                        </ol>
                    </div>
                </div>
            </div>-->
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Appointment Data Table</strong>
                            </div>
                            <!--<div class="card-body">-->
                            <div class="col-md-9" style="overflow-x: auto">

                                <table id="bootstrap-data-table-export" class="table table-striped table table-responsive">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            
                                            <th>Name</th>
                                            <th>Phone Number</th>
                                            <th>Email</th>
                                            <th>Address</th>
                                            <th>Doctor Name</th>
                                            <th>Specialization</th>
                                            <th>Appointment_Date</th>
                                            <th>Appointment_Time</th>
                                            <th>Booking_status</th>
                                            <th>Payment_status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                   
                                    <?php
                                        $count=0;
                                        // $sr_no=1;
                                       // $res=mysqli_query($link,"select * from patient_appointments");
                                       $res=mysqli_query($link,"select * from patient_appointments WHERE status=1");
                                           while($row=mysqli_fetch_array($res))
                                        {
                                          $count=$count+1;                      
                                            ?>
                                                <tr>
                                            <th scope="row"><?php echo $count; ?></th>
                                            
                                            <td><?php echo $row["name"]?></td>
                                            <td><?php echo $row["moblie"]?></td>
                                            <td><?php echo $row["email"]?></td>
                                            <td><?php echo $row["address"]?></td>
                                            <td><?php echo $row["doctor_name"]?></td>
                                            <td><?php echo $row["specialist"]?></td>
                                            <td><?php echo $row["appointment_date"]?></td>
                                            <td><?php echo $row["appointment_time"]?></td>
                                            <td><?php echo $row["booking_status"]?></td>
                                            <td><?php echo $row["payment_status"]?></td>
                                            <!--<td><img src="<php echo $row["photo"]; ?>" height="50" width="50"></td>
                                            <td><a href="edit_doctor.php?id=<php echo $row["id"]; ?>">Edit</a></td>-->
                                          <!--  <td><a class="btn btn-danger" href="delete.php?id=<php echo $row["id"]; ?>">Delete</a></td>-->
                                        </tr>

                                            <?php
                                        }
                                        
                                        ?>

                                      
                             
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


    </div><!-- /#right-panel -->

    <!-- Right Panel -->


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="vendors/jszip/dist/jszip.min.js"></script>
    <script src="vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <script src="assets/js/init-scripts/data-table/datatables-init.js"></script>


</body>

</html>
