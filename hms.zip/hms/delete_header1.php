<?php
include("auth_session1.php");     
include("connection.php");

$id=$_GET["id"];
mysqli_query($link,"delete from header1 where id=$id");
?>

<script type="text/javascript">
alert("Header Deleted successfully");
window.location="upload_header.php";
</script>
