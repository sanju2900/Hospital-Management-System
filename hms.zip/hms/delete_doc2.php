<?php
include("auth_session.php");     
include("connection.php");

$id=$_GET["id"];
mysqli_query($link,"delete from doctor where id=$id");
?>

<script type="text/javascript">
alert("Doctor Deleted successfully");
window.location="delete_doc1.php";
</script>
