<?php
include("auth_session1.php");
include "header2.php";
include "connection.php";
?>
<!--
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Add patient</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://fonts.googleapis.com/css?family=Play:400,700" rel="stylesheet">
       <link rel="stylesheet" href="css1/bootstrap.min.css">
       <link rel="stylesheet" href="css1/font-awesome.min.css">
      <link rel="stylesheet" href="css1/owl.carousel.css">
    <link rel="stylesheet" href="css1/owl.theme.css">
    <link rel="stylesheet" href="css1/owl.transitions.css">
      <link rel="stylesheet" href="css1/animate.css">
      <link rel="stylesheet" href="css1/normalize.css">
      <link rel="stylesheet" href="css1/main.css">
      <link rel="stylesheet" href="style.css">
       <link rel="stylesheet" href="css1/responsive.css">
      <script src="js/vendor/modernizr-2.8.3.min.js"></script>

<script>
function myfunc()
{
    var name=document.forms["abc"]["name"].value;
    var re=/^[a-zA-Z]{2,10}$/;
    if(!re.test(name))
    {
    alert("invalid name...name must be between 2 to 10 characters");
    document.forms["abc"]["name"].focus();
    return false;
    }

    var age=document.forms["abc"]["age"].value;
    var re2=/^([1-9]{1})([0-3]{1-3})$/;
    if(!re2.test(age))
    {
    alert("invalid age");
    document.forms["abc"]["age"].focus();
    return false;
    }


    var address=document.forms["abc"]["address"].value;
    var re=/^[a-zA-Z]{2,100}$/;
    if(!re.test(address))
    {
    alert("invalid address...address must be between 2 to 100 characters");
    document.forms["abc"]["address"].focus();
    return false;
    }

    var phone=document.forms["abc"]["phone"].value;
    var re2=/^([6-9]{1})([0-9]{9})$/;
    if(!re2.test(phone))
    {
    alert("invalid Mobile number,should have 10 digit and starting no. be 6-9");
    document.forms["abc"]["phone"].focus();
    return false;
    }

    var gender=document.forms["abc"]["gender"].value;
    var l3=gender.length;
    if(l3==0)
    {
    alert("please select any gender");
    document.forms["abc"]["gender"].focus();
    return false;
    }

    var guardian_name=document.forms["abc"]["guardian_name"].value;
    var re=/^[a-zA-Z]{2,20}$/;
    if(!re.test(guardian_name))
    {
    alert("invalid guardian_name...guardian_name must be between 2 to 20 characters");
    document.forms["abc"]["guardian_name"].focus();
    return false;
    }

    document.writeln("<b>Name:</b> "+document.abc.name.value+"<br/>"+
    "<b>Age:</b> "+document.abc.age.value+"<br/>"+
    "<b>Address:</b> "+document.abc.address.value+"<br/>"+
    "<b>Contact:</b> "+document.abc.phone.value+"<br/>"+
    "<b>Gender:</b> "+document.abc.gender.value+"<br/>"+
    "<b>Guardian Name:</b> "+document.abc.guardian_name.value); 
    
   
}


</script>

</head>

<body>

	<div class="error-pagewrap">
		<div class="error-page-int">
			<div class="text-center custom-login">
				<h3  style="text-color:white;">Add Patient</h3>

			</div>
			<div class="content-error">
				<div class="hpanel">
                    <div class="panel-body">
                        <form action="" name="form1" method="post">
                            <div class="row">
                                <div class="form-group col-lg-12">
                                    <label>Name</label>
                                    <input type="text" name="name" placeholder="Name" class="form-control">
                                </div>
                                <div class="form-group col-lg-12">
                                    <label>Age</label>
                                    <input type="number" name="age" placeholder="Age" class="form-control">
                                </div>
                                <div class="form-group col-lg-12">
                                    <label>Address</label>
                                    <input type="text" name="address" placeholder="Address" class="form-control">
                                </div>
                                <div class="form-group col-lg-12">
                                    <label>Contact</label>
                                    <input type="number" name="phone" placeholder="phone number" class="form-control">
                                </div>
                                <div class="form-group col-lg-12">
                                    <label><b>Gender:</b></label><br>
                                    
                                    <input type="radio" name="gender" value="male">
                                    <label>Male</label>
                                    <input type="radio" name="gender" value="female">
                                    <label>Female</label>

                                    <input type="radio" name="gender" value="other">
                                    <label>Other</label>

                                    </div>
                                <div class="form-group col-lg-12">
                                <label>Guardian Name</label>
                                <input type="text" name="guardian_name" placeholder="Guardian Name" class="form-control">
                            </div>
                                
                            <div class="form-group col-lg-12">
                                <label></label>
                                <input type="hidden" name="dt" placeholder="Guardian Name" class="form-control">
                            </div>
                              </div>
                            <div class="text-center">
                                <button type="submit" name="submit1" class="btn btn-success" onclick="myfunc()">Add Patient</button>
                                <a type="button" href="applist1.php" class="btn btn-success" value="BACK">BACK</a>
                            </div>

                        </form>
                    </div>
                </div>
			</div>

		</div>   
    </div>


    <php
if(isset($_POST['submit1']))
{
    mysqli_query($link,"insert into patient value(NULL,'$_POST[name]','$_POST[age]','$_POST[address]','$_POST[phone]','$_POST[gender]','$_POST[guardian_name]','$_POST[dt]')") or die(mysqli_error($link));

    ?>
    <script type="text/javascript">
     alert("Patient add successfully");
      window.location="register.php";
    </script>
    <php

}
?>


    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery-price-slider.js"></script>
    <script src="js/jquery.meanmenu.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

</body>

</html>-->



<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Add patient</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://fonts.googleapis.com/css?family=Play:400,700" rel="stylesheet">
       <link rel="stylesheet" href="css1/bootstrap.min.css">
       <link rel="stylesheet" href="css1/font-awesome.min.css">
      <link rel="stylesheet" href="css1/owl.carousel.css">
    <link rel="stylesheet" href="css1/owl.theme.css">
    <link rel="stylesheet" href="css1/owl.transitions.css">
      <link rel="stylesheet" href="css1/animate.css">
      <link rel="stylesheet" href="css1/normalize.css">
      <link rel="stylesheet" href="css1/main.css">
      <link rel="stylesheet" href="style.css">
       <link rel="stylesheet" href="css1/responsive.css">
      <script src="js/vendor/modernizr-2.8.3.min.js"></script>



</head>

<body>

	<div class="error-pagewrap">
		<div class="error-page-int">
			<div class="text-center custom-login">
				<h3  style="text-color:white;">Add Patient</h3>

			</div>
			<div class="content-error">
				<div class="hpanel">
                    <div class="panel-body">
                        <form action="" name="abc" method="post" onsubmit="return validateForm()">
                            <div class="row">
                                <div class="form-group col-lg-12">
                                    <label>Name</label>
                                    <input type="text" name="name" placeholder="Name" class="form-control">
                                </div>
                                <div class="form-group col-lg-12">
                                    <label>Age</label>
                                    <input type="number" name="age" placeholder="Age" class="form-control">
                                </div>
                                <div class="form-group col-lg-12">
                                    <label>Address</label>
                                    <input type="text" name="address" placeholder="Address" class="form-control">
                                </div>
                                <div class="form-group col-lg-12">
                                    <label>Contact</label>
                                    <input type="number" name="phone" placeholder="phone number" class="form-control">
                                </div>
                                <div class="form-group col-lg-12">
                                    <label><b>Gender:</b></label><br>
                                    
                                    <input type="radio" name="gender" value="male">
                                    <label>Male</label>
                                    <input type="radio" name="gender" value="female">
                                    <label>Female</label>

                                    <input type="radio" name="gender" value="other">
                                    <label>Other</label>

                                    </div>
                                <div class="form-group col-lg-12">
                                <label>Guardian Name</label>
                                <input type="text" name="guardian_name" placeholder="Guardian Name" class="form-control">
                            </div>
                                
                            <div class="form-group col-lg-12">
                                <label></label>
                                <input type="hidden" name="dt" placeholder="Guardian Name" class="form-control">
                            </div>
                              </div>
                            <div class="text-center">
                                <button type="submit" name="submit1" class="btn btn-success">Add Patient</button>
                                <a type="button" href="applist1.php" class="btn btn-success" value="BACK">BACK</a>
                            </div>

                        </form>
                    </div>
                </div>
			</div>

		</div>   
    </div>


    <?php
if(isset($_POST['submit1']))
{
    mysqli_query($link,"insert into patient value(NULL,'$_POST[name]','$_POST[age]','$_POST[address]','$_POST[phone]','$_POST[gender]','$_POST[guardian_name]','$_POST[dt]')") or die(mysqli_error($link));

    ?>
    <script type="text/javascript">
     alert("Patient add successfully");
      window.location="register.php";
    </script>
    <?php

}
?>


    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery-price-slider.js"></script>
    <script src="js/jquery.meanmenu.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

<script>
function validateForm()
{
    var name=document.forms["abc"]["name"].value;
    var re=/^[a-zA-Z]{2,10}$/;
    if(!re.test(name))
    {
    alert("invalid name...name must be between 2 to 10 characters");
    document.forms["abc"]["name"].focus();
    return false;
    }

    var age=document.forms["abc"]["age"].value;
    var re2=/^([1-9]{1})([0-3]{1-3})$/;
    if(!re2.test(age))
    {
    alert("invalid age");
    document.forms["abc"]["age"].focus();
    return false;
    }


    var address=document.forms["abc"]["address"].value;
    var re=/^[a-zA-Z]{2,100}$/;
    if(!re.test(address))
    {
    alert("invalid address...address must be between 2 to 100 characters");
    document.forms["abc"]["address"].focus();
    return false;
    }

    var phone=document.forms["abc"]["phone"].value;
    var re2=/^([6-9]{1})([0-9]{9})$/;
    if(!re2.test(phone))
    {
    alert("invalid Mobile number,should have 10 digit and starting no. be 6-9");
    document.forms["abc"]["phone"].focus();
    return false;
    }

    var gender=document.forms["abc"]["gender"].value;
    var l3=gender.length;
    if(l3==0)
    {
    alert("please select any gender");
    document.forms["abc"]["gender"].focus();
    return false;
    }

    var guardian_name=document.forms["abc"]["guardian_name"].value;
    var re=/^[a-zA-Z]{2,20}$/;
    if(!re.test(guardian_name))
    {
    alert("invalid guardian_name...guardian_name must be between 2 to 20 characters");
    document.forms["abc"]["guardian_name"].focus();
    return false;
    }

    document.writeln("<b>Name:</b> "+document.abc.name.value+"<br/>"+
    "<b>Age:</b> "+document.abc.age.value+"<br/>"+
    "<b>Address:</b> "+document.abc.address.value+"<br/>"+
    "<b>Contact:</b> "+document.abc.phone.value+"<br/>"+
    "<b>Gender:</b> "+document.abc.gender.value+"<br/>"+
    "<b>Guardian Name:</b> "+document.abc.guardian_name.value); 
    
   
}


</script>
</body>

</html>