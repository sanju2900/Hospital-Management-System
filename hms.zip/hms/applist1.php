<?php
include "auth_session1.php";
include "header2.php";
include "connection.php";
/*if(!isset($_SESSION['doctor_name']))
{
    header("location:applist1.php");
    die();
   
}*/

?>

<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
            <?php  
             $id=$_SESSION["id"];
             // $count=0;
             $res=mysqli_query($link,"select * from doctor WHERE id=$id");
             while($row=mysqli_fetch_array($res))
             {
                 ?>
                <h1 style="color:red;"><b><i>Welcome Doctor <?php echo $row["doctor_name"]?> </i></b></h1>

                 <?php
             }
            ?>
            </div>
        </div>
    </div>
    <!--  <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Dashboard</a></li>
                            <li><a href="#">Table</a></li>
                            <li class="active">Data table</li>
                        </ol>
                    </div>
                </div>
            </div>-->
</div>

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Doctor Data Table</strong>
                    </div>
                    <div class="col-md-9" style="overflow-x: auto">
                        <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>Specialization</th>
                                    <th>Address</th>
                                    <th>Password</th>
                                    <th>Edit</th>

                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                    
                                    $id=$_SESSION["id"];
                                        // $count=0;
                                        $res=mysqli_query($link,"select * from doctor WHERE id=$id");
                                        while($row=mysqli_fetch_array($res))
                                        {
                                            
                                          //$count=$count+1;
                                          if($row["activity"]=="on"){
                                            $activity_status="checked";
                                          }else{
                                            $activity_status="unchecked";
                                          }
                                         

                                        ?>
                                <tr>

                                    <td><?php echo $row["doctor_name"]?></td>
                                    <td><?php echo $row["email"]?></td>

                                    <td>
                                        <label class="switch switch-text switch-success switch-pill">
                                            <input type="checkbox" class="switch-input" <?php echo $activity_status; ?>
                                                value="<?php echo $activity_status; ?>"
                                                onchange="updateDoctorActivity(this.value,' <?php echo $id; ?>');" />
                                            <span data-on="on" data-off="off" class="switch-label"></span>
                                            <span class="switch-handle"></span></label>
                                    </td>
                                    <td><?php echo $row["specialist"]?></td>

                                          <td><?php echo $row["location"]?></td>
                                          <td><?php echo $row["password"]?></td>
                                          <td><a class="btn btn-success" style="border-radius:15px;" href="edit_doctor1.php?id=<?php echo $row["id"]; ?>">Edit</a></td>

                                </tr>

                                <?php
                                        }
                                        
                                        ?>



                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div><!-- .animated -->
</div><!-- .content -->


</div><!-- /#right-panel -->

<!-- Right Panel -->


<script src="vendors/jquery/dist/jquery.min.js"></script>
<script src="vendors/popper.js/dist/umd/popper.min.js"></script>
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>

<!-- status on/off -->

<script src="js/ajaxlogic.js">



</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>


</body>

</html>

