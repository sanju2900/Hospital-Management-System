 
   <?php
   include("auth_session.php");
         include("header.php");
         include("connection.php");

        $id=$_GET["id"];
         $res=mysqli_query($link,"select * from user where id=$id");
         while($row=mysqli_fetch_array($res))
         {
             $name=$row["name"];
             $phone=$row["moblie"];
             $email=$row["email"];
             $password=$row["password"];
             $address=$row["address"];
         }

    ?>



        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Update Patient</h1>
                    </div>
                </div>
            </div>
                </div>

        <div class="content mt-3">
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <form name="form1" action="" method="post">
                            <div class="card-body">
                                <!-- Credit Card -->
                                
                                <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Update Patient</strong></div>
                            <div class="card-body card-block">
                                <div class="form-group"><label for="company" class=" form-control-label">Name</label><input type="text" name="name" value="<?php echo $name;?>" placeholder="Name" class="form-control"></div>
                                    <div class="form-group"><label for="vat" class=" form-control-label">Mobile</label><input type="number" name="phone" value="<?php echo $phone;?>" placeholder="Phone Number" class="form-control"></div>
                                        <div class="form-group"><label for="street" class=" form-control-label">Email</label><input type="email" name="email" value="<?php echo $email;?>" placeholder="Email" class="form-control"></div>
                                            <div class="form-group"><label for="street" class=" form-control-label">Password</label><input type="text" name="password" value="<?php echo $password;?>" placeholder="Password" class="form-control"></div>
                                            <div class="form-group"><label for="street" class=" form-control-label">Address</label><input type="text" name="address" value="<?php echo $address;?>" placeholder="Address" class="form-control"></div>


                                        <div class="form-group">
                                        <input type="submit" name="submit1" class="btn btn-success" value="Update Patient">
                                        </div>

                                         </div>
                                 </div>
                           </div>

                            
                    </div>
                    </form>



                        </div> <!-- .card -->

                    </div>
                    <!--/.col-->

                
                
                
                </div>
                                        </div><!-- .animated -->
                                    </div><!-- .content -->

  <?php
if(isset($_POST['submit1']))
{
    mysqli_query($link,"update user set name='$_POST[name]',moblie='$_POST[phone]',email='$_POST[email]',password='$_POST[password]',address='$_POST[address]' where id=$id") or die(mysqli_error($link));
    ?>
    <script type="text/javascript">
     
      window.location="patient.php";
    </script>
    <?php

}
?>




        <?php
         include("footer.php");
         ?>
 