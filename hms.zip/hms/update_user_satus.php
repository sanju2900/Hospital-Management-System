<?php
session_start();
include ("connection.php");
$uid=$_SESSION["username"];
$time=time() +10;
$res=mysqli_query($link,"update doctor set status=$time WHERE id='$uid'");


?>
