

                                            <?php
include("auth_session1.php");
include "header2.php";
include "connection.php";
?>
  
  <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><b><i>Welcome!!! To Doctor List</i></b></h1>
                    </div>
                </div>
            </div>
        
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Doctor Data Table</strong>
                            </div>
                            <div class="col-md-9" style="overflow-x: auto">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Name</th>
                                            <th>Age</th>
                                            <th>Address</th>
                                            <th>Phone</th>
                                            <th>Gender</th>
                                            <th>Guardian Name</th>
                                            <th>Print</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        
                                        $count=0;
                                        $res=mysqli_query($link,"select * from patient");
                                        while($row=mysqli_fetch_assoc($res))
                                        {
                                           
                                          
                                          $count=$count+1;                      
                                            ?>
                                                <tr>
                                            <th scope="row"><?php echo $count; ?></th>
                                            <td><?php echo $row["name"]?></td>
                                            <td><?php echo $row["age"]?></td>
                                            <td><?php echo $row["address"]?></td>
                                            <td><?php echo $row["phone"]?></td>
                                            <td><?php echo $row["gender"]?></td>
                                            <td><?php echo $row["guardian_name"]?></td>

                                          <td><a class="btn btn-danger" style="border-radius: 15px;" href="print1.php?id=<?php echo $row["id"]; ?>">Print</a></td>
                                          <!--  <td><a class="btn btn-danger" href="delete.php?id=<php echo $row["id"]; ?>">Delete</a></td>-->
                                        </tr>

                                            <?php
                                        }
                                        
                                        ?>

                                      
                             
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


    </div><!-- /#right-panel -->

<!-- status of doctor -->

<script>
function updateUserStatus()
{
    jQuery.ajax({
        url:'update_user_satus.php';
        success:function()
        {

        }
    });
}
//automatically run
setInterval(function(){
    updateUserStatus();
}, 5000);
</script>


    <!-- Right Panel -->


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="vendors/jszip/dist/jszip.min.js"></script>
    <script src="vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <script src="assets/js/init-scripts/data-table/datatables-init.js"></script>


</body>

</html>
