<?php


   $servername = 'localhost';
   $username = 'root';
   $password = '';
   $dbname = 'u666708222_umesh';





   $link = mysqli_connect($servername, $username, $password, $dbname);

/*


        $username = 'u666708222_umesh';
        $password = 'Umesh12345';
        $dbname = 'u666708222_umesh';
       // $servername = 'mnds.tech';
        $servername = 'localhost';
        $port=3306;

     
        $link = mysqli_connect($servername, $username, $password, $dbname, $port);

 */

?>