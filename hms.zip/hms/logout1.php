<?php
include "connection.php";
session_start();
$id=$_SESSION['id'];

$sql="update doctor set status='offline' WHERE id=$id";
mysqli_query($link,$sql);
           


if(session_destroy())
{
    header("location:index.php");
}
?>