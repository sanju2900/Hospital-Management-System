 
   <?php
   include("auth_session1.php");
         include("header2.php");
         include("connection.php");

        $id=$_GET["id"];
         $res=mysqli_query($link,"select * from doctor where id=$id");
         while($row=mysqli_fetch_array($res))
         {
             $name=$row["doctor_name"];
             $email=$row["email"];
             $spe=$row["specialist"];
             $address=$row["location"];
             $password=$row["password"];
        
         }

    ?>



        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Update Doctor</h1>
                    </div>
                </div>
            </div>
                </div>

        <div class="content mt-3">
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <form name="form1" action="" method="post">
                            <div class="card-body">
                                <!-- Credit Card -->
                                
                                <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Update Doctor</strong></div>
                            <div class="card-body card-block">
                            <div class="form-group"><label for="company" class=" form-control-label">Name</label><input type="text" name="doctor_name" value="<?php echo $name;?>" placeholder="Name" class="form-control"></div>
                                        <div class="form-group"><label for="street" class=" form-control-label">Email</label><input type="email" name="email" value="<?php echo $email;?>" placeholder="Email" class="form-control"></div>
                                        <div class="form-group"><label for="vat" class=" form-control-label">Specialization</label><select name="specialist" value="<?php echo $spe;?>" class="form-control">
                                        <?php
                                    $sql="SELECT * FROM specialization";
                            $res=mysqli_query($link,$sql);
                            while($row=mysqli_fetch_array($res))
                            {
                                ?>
                                <option value="<?php echo $row["specialization"];?>"><?php echo $row["specialization"];?></option>
                                <?php
                            }

                            ?>
                                        </select></div>
                                        <div class="form-group"><label for="street" class=" form-control-label">Address</label><input type="text" name="location" value="<?php echo $address;?>" placeholder="Address" class="form-control"></div>
                                        <div class="form-group"><label for="street" class=" form-control-label">Password</label><input type="text" name="password" value="<?php echo $password;?>" placeholder="password" class="form-control"></div>

                                        <div class="form-group">
                                        <input type="submit" name="submit1" class="btn btn-success" value="Update Doctor">
                                        </div>

                                         </div>
                                 </div>
                           </div>

                            
                    </div>
                    </form>



                        </div> <!-- .card -->

                    </div>
                    <!--/.col-->

                
                
                
                </div>
                                        </div><!-- .animated -->
                                    </div><!-- .content -->

  <?php
if(isset($_POST['submit1']))
{
    mysqli_query($link,"update doctor set doctor_name='$_POST[doctor_name]',email='$_POST[email]',specialist='$_POST[specialist]',location='$_POST[location]',password='$_POST[password]' where id=$id") or die(mysqli_error($link));
    ?>
    <script type="text/javascript">
     
      window.location="applist1.php";
    </script>
    <?php

}
?>




        <?php
         include("footer.php");
         ?>
 