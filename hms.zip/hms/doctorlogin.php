
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Doctor</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body class="bg-dark" style="background-image: url(images/page1.png);">


    <div class="sufee-login d-flex align-content-center flex-wrap">
        <div class="container">
            <div class="login-content">
                <div class="login-logo" style="color:black">
                  <!--  <a href="index.html">
                        <img class="align-content" src="images/alogin.png" alt="">
                    </a>-->
                </div>
                <div class="col-lg-10">
                <div class="login-form">
                    <form name="form1" action="" method="POST">
                    <h1><b>Doctor Login</b></h1>

                        <div class="form-group">
                            <label>Doctor Email</label>
                            <input type="text" name="email" class="form-control" placeholder="email">
                        </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" name="password" class="form-control" placeholder="Password">
                        </div>

                                <button type="submit" name="submit1" class="btn btn-success btn-flat m-b-30 m-t-30">Login</button>
                                <div class="alert alert-danger" id="Failure" style="margin-top:10px; display:none">
                                <strong>Does Not Match!</strong>Invalid username or password
                                </div>
 
                             <!--   <div class="register-link m-t-15 text-center">
                                    <p>Don't have account ? <a href="#"> Sign Up Here</a></p>
                                </div>-->
                    </form>
                </div>
                </div>
            </div>
        </div>
    </div>

    <?php
if(isset($_POST["submit1"]))
{
   // $username=mysqli_real_escape_string($link,$_POST["doctor_email"]);//escape_string is use to reject mysql injection
   // $password=mysqli_real_escape_string($link,$_POST["password"]);//escape_string is use to reject mysql injection
   
    include "connection.php";
   // $user=$_POST["email"];
    //$pass=$_POST["password"];
    $user=mysqli_real_escape_string($link,$_POST["email"]);//escape_string is use to reject mysql injection
   $pass=mysqli_real_escape_string($link,$_POST["password"]);//escape_string is use to reject mysql injection
   
  //  $count=0;
    $sql="select * from doctor where `email`='$user' AND `password`='$pass'";

    $res=mysqli_query($link, $sql);
    //$count=mysqli_num_rows($res);
    if($res){
        if(mysqli_num_rows($res)>0){
            while($row=mysqli_fetch_assoc($res))
            {
                $id=$row['id'];
                $name=$row['doctor_name'];
                $email=$row['email'];
            }
            
            $sql="update doctor set status='online' WHERE id=$id";
            mysqli_query($link,$sql);
            $login = 'NOW()';
            $link=mysqli_query($link,"update admin set logindatetime=NOW() where id='$_POST[id]'");
            
            session_start();
            $_SESSION['doctor_name']=$name;
            $_SESSION['id']=$id;
            $_SESSION['email']=$email;
            
           // echo "<h1>ID: $id, Session Started.</h1>";



        header("location:applist1.php");
           
        }else{
            echo "<h1>Invalid Email or Password</h1>";
        }
    }else{
       echo "<h1> Query Exicution failed</h1>";
    }
}
   

?>


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


</body>

</html>
