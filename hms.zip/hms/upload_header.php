<?php include("auth_session1.php"); ?>
<?php

	 include("header2.php");
	 include("connection.php");
	 
?>



        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Upload Header</h1>
                    </div>
                </div>
            </div>
                </div>

        <div class="content mt-3">
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <form name="form1" action="" method="post" enctype="multipart/form-data">
                            <div class="card-body">
                                <!-- Credit Card -->
                                
                            <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Upload Bill</strong></div>
                            <div class="card-body card-block">
                                
                                        <div class="form-group"><label for="street" class=" form-control-label">Bill Header</label><input type="file" name="bill_photo" id="myFile"></div>

                                        <div class="form-group">
                                        <input type="submit" name="submit1" class="btn btn-success" value="Upload Bill">
                                        </div>

                                                </div>
                                           </div>
                           </div>

                            
                        </form>



                        </div> <!-- .card -->

                    </div>
                    <!--/.col-->


                    <div class="col-lg-12">
                        <div class="card">
                            <form name="form1" action="" method="post" enctype="multipart/form-data">
                            <div class="card-body">
                                <!-- Credit Card -->
                                
                            <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Upload Prescription</strong></div>
                            <div class="card-body card-block">
                                
                                        <div class="form-group"><label for="street" class=" form-control-label">Prescription Header</label><input type="file" name="pre_photo" id="myFile"></div>

                                        <div class="form-group">
                                        <input type="submit" name="submit2" class="btn btn-success" value="Upload Prescription">
                                        </div>

                                                </div>
                                           </div>
                           </div>

                            
                        </form>



                        </div> <!-- .card -->

                    </div>
                    <!--/.col-->


                </div>





                <div class="col-md-9" style="overflow-x: auto">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                           
                                            <th>Bill Photo </th>
                                            <th>Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        $count=0;
                                        $res=mysqli_query($link,"select * from header1");
                                        while($row=mysqli_fetch_assoc($res))
                                        {
                                          
                                          $count=$count+1;                      
                                            ?>
                                                <tr>
                                            <th scope="row"><?php echo $count; ?></th>
                                            

                                            <td><img src="<?php echo $row["bill_photo"];?>" height="50" width="50"></td>

                                          <td><a class="btn btn-danger" href="delete_header1.php?id=<?php echo $row["id"]; ?>">Delete</a></td>
                                        </tr>

                                            <?php
                                        }
                                        
                                        ?>

                                      
                             
                                    </tbody>
                                </table>
                            </div>




                            <div class="col-md-9" style="overflow-x: auto">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                           
                                            <th>Prescription Photo</th>
                                            <th>Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        $count=0;
                                        $res=mysqli_query($link,"select * from header");
                                        while($row=mysqli_fetch_assoc($res))
                                        {
                                          
                                          $count=$count+1;                      
                                            ?>
                                                <tr>
                                            <th scope="row"><?php echo $count; ?></th>
                                            

                                            <td><img src="<?php echo $row["pre_photo"];?>" height="50" width="50"></td>

                                          <td><a class="btn btn-danger" href="delete_header.php?id=<?php echo $row["id"]; ?>">Delete</a></td>
                                        </tr>

                                            <?php
                                        }
                                        
                                        ?>

                                      
                             
                                    </tbody>
                                </table>
                            </div>


            </div><!-- .animated -->
                                    </div><!-- .content -->

  <?php
if(isset($_POST['submit1']))
{
    
    $img_loc = $_FILES['bill_photo']['tmp_name'];
    $img_name=$_FILES['bill_photo']['name'];
  
  $img_des="upload/".$img_name;


 $res= mysqli_query($link,"insert into header1 value(NULL,'$img_des')") or die(mysqli_error($link));
if($res)
{
    move_uploaded_file($img_loc,$img_des);  
    echo ' <script type="text/javascript">
    alert("Bill Header added successfully");
    window.location.href=window.location.href;
  </script>';
}
else
{
    echo ' <script type="text/javascript">
    alert("Bill Header added Failed");
    window.location.href=window.location.href;
  </script>';
}

}
?>



<?php
if(isset($_POST['submit2']))
{
    
    


  $img_loc1 = $_FILES['pre_photo']['tmp_name'];
  $img_name1=$_FILES['pre_photo']['name'];

$img_des1="upload/".$img_name1;
  
 $res= mysqli_query($link,"insert into header value(NULL,'$img_des1')") or die(mysqli_error($link));
if($res)
{
    move_uploaded_file($img_loc,$img_des);  
    echo ' <script type="text/javascript">
    alert("Prescription Header added successfully");
    window.location.href=window.location.href;
  </script>';
}
else
{
    echo ' <script type="text/javascript">
    alert("Prescription Header added Failed");
    window.location.href=window.location.href;
  </script>';
}

}
?>




        <?php
         include("footer.php");
         ?>
 




 