<?php
 include "connection.php";
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>HOME PAGE</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header" style="background-color:#566573;">
            <div class="header-menu">
           
               <div class="col-sm-7">
               
                    <div class="header-left mr-sm-6" style="background-color:#566573">
                        <h1 style="color:white">DOCTOR BOOKING SYSTEM</h1>
                        
                    </div >
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                   <a class="navbar-brand brand-logo mr-5" href="#"><img src="images/doc1.png" class="mr-2" alt="logo" width="300" height="100"/></a>
                    <!-- <h1 style="color:white">Mindstein <sub></sub></h1>
                    <h3>Obviously Intelligent!</h3>-->

                      <!--  <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/logo23.png" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="#"><i class="fa fa-user"></i> My Profile</a>
                            

                            <a class="nav-link" href="#"><i class="fa fa-power-off"></i> Logout</a>
                        </div>-->
                    </div>



                </div>
            </div>

        </header><!-- /header -->
        <!-- Header-->


<html>
<body style="background-image: url(images/page1.png);background-repeat: no-repeat;
  background-size: auto;">
    
<!--
<html>
<head>
<title>HMS Home Page</title>
</head>
<body>

   <div class="container">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-3 mx-1 shadow">
                    <img src="info.PNG">
                </div>
                <div class="col-md-3 mx-4 shadow">
                    <img src="img/patient.PNG" style="width: 100%">
                </div>
                <div class="col-md-3 mx-4 shadow">
                    <img src="img/dr.PNG"style="width: 100%">
                </div>
            </div>
        </div>-->
        <div style="margin-top: 100px"></div>
    <div class="container">
            <div class="row">
        <div class="col-md-4">
            <div class="thumbnail">
                <img src="images/infor.png" alt="Lights" style="width:100%">
                <div class="caption">
                <h2 class="text-center"><b>Admin</b></h2>
                <a href="login.php" type="button" class="btn btn-success">Login Admin</a>
                
                </div>
            
            </div>
        </div>
        <div class="col-md-4">
            <div class="thumbnail">
                <img src="images/patient.png" alt="Nature" style="width:100%">
                <div class="caption">
                <h2 class="text-center"><b>Patient</b></h2>
                <a href="#" type="button" class="btn btn-success" >Login Patient</a>
                
                </div>
            
            </div>
        </div>
        <div class="col-md-4">
            <div class="thumbnail">
                <img src="images/dr.png" alt="Fjords" style="width:100%">
                <div class="caption">
                <h2 class="text-center"><b>Doctor</b></h2>
                <a href="doctorlogin.php" type="button" class="btn btn-success">Login Doctor</a>
                </div>
            
            </div>
        </div>
        </div>
    </div>
 <!--
   
</body>
</html>-->
</body>

</html>
