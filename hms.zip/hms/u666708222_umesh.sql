-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2021 at 01:40 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u666708222_umesh`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(200) NOT NULL,
  `username` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logindatetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `profile`, `logindatetime`) VALUES
(1, 'admin', 'admin123', 'blank', '2021-07-24 14:32:33');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `id` int(200) NOT NULL,
  `doctor_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specialist` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qualification` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fee` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'on',
  `photo` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`id`, `doctor_name`, `specialist`, `email`, `phone`, `qualification`, `password`, `fee`, `location`, `status`, `activity`, `photo`) VALUES
(1, 'Dr.sanjana kumari', 'Medicine Specialist', 'sanjanakumari8864@gmail.com', '9876543210', 'MBBS', 'Sanju@2900', '500', 'banjara hills, Hyderabad', 'online', 'off', 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(3, 'Dr.Raj', 'Medicine Specialist', 'raj@gmail.com', '9703997198', 'MD', 'Raj@2900', '1000', 'Ropar,Bombay', 'offline', 'off', 'https://images.unsplash.com/photo-1612349316228-5942a9b489c2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(4, 'Dr. sundar', 'Medicine specialist', 'sundar@gmail.com', '9874561230', 'MBBS', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1612349316228-5942a9b489c2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(5, 'Dr. Yaswanth', 'Medicine specialist', 'Yaswanth@gmail.com', '9874561230', 'MD', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1618498082410-b4aa22193b38?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(6, 'Dr. Ramu', 'Medicine specialist', 'ramu@gmail.com', '9874561230', 'MBBS', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'off', 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=334&q=80'),
(7, 'Dr.sparsh', 'Child specialist', 'sundar@gmail.com', '9874561230', 'MBBS', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1618498082410-b4aa22193b38?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(8, 'Dr.pawan', 'Child specialist', 'pawan@gmail.com', '9874561230', 'MD', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1612349316228-5942a9b489c2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(11, 'Dr.vamsi', 'Dentist', 'vamsi@gmail.com', '9874561230', 'MBBS', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1618498082410-b4aa22193b38?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(12, 'Dr.kalyan', 'Dentist', 'kalyan@gmail.com', '9874561230', 'MD', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1612349316228-5942a9b489c2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(13, 'Dr.chaitanaya', 'Urologist', 'chaitanaya@gmail.com', '9874561230', 'MBBS', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1612349316228-5942a9b489c2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(14, 'Dr.hasan', 'Urologist', 'hasan@gmail.com', '9874561230', 'MBBS', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=334&q=80'),
(15, 'Dr.kamal', 'Skin and hair', 'kamal@gmail.com', '9874561230', 'MD', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=334&q=80'),
(16, 'Dr.kiran', 'Skin and hair', 'kiran@gmail.com', '9874561230', 'MBBS', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1612349316228-5942a9b489c2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(17, 'Dr.govind', 'Eye', 'govind@gmail.com', '9874561230', 'MBBS', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1612349316228-5942a9b489c2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(18, 'Dr.anushka', 'Eye', 'anushka@gmail.com', '9874561230', 'MD', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(19, 'Dr.thammana', 'Neurology', 'thammana@gmail.com', '9874561230', 'MBBS', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(20, 'Dr.keerthi', 'Neurology', 'keerthi@gmail.com', '9874561230', 'MD', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1591604021695-0c69b7c05981?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(21, 'Dr.kajal', 'Orthopedic', 'kajal@gmail.com', '9874561230', 'MBBS', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1591604021695-0c69b7c05981?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(22, 'Dr.sam', 'Orthopedic', 'sam@gmail.com', '9874561230', 'MBBS', 'sundar', '500', 'jublie hills, hyderabad', 'offline', 'on', 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(32, 'Dr.Umesh', 'Child Specialist', 'umesh@gmail.com', '6353150970', 'MBBS', '12345', '100000', 'rajedar chowk', 'offline', 'off', 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'),
(47, 'Dr.sinha', 'Dentist', 'sinha@gmail.com', '6353150975', 'MD', '12345', '12365', 'rajedar chowk', 'offline', 'off', 'upload/Dr.sinha.png'),
(48, 'krishu', 'Urologist', 'krisg@gmail.com', '1236547890', 'MD', '123654', '100000', 'rajedar chowk', 'offline', 'off', 'upload/krishu.jpeg'),
(50, 'Dr.surabh', 'Cardiologist', 'surabh@gmail.com', '6353150976', 'MBBS', '12345', '100000', 'rajedar chowk', 'offline', 'off', 'upload/Dr.surabh.png');

-- --------------------------------------------------------

--
-- Table structure for table `header`
--

CREATE TABLE `header` (
  `id` int(200) NOT NULL,
  `pre_photo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `header`
--

INSERT INTO `header` (`id`, `pre_photo`) VALUES
(6, 'upload/print.png');

-- --------------------------------------------------------

--
-- Table structure for table `header1`
--

CREATE TABLE `header1` (
  `id` int(200) NOT NULL,
  `bill_photo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `header1`
--

INSERT INTO `header1` (`id`, `bill_photo`) VALUES
(1, 'upload/bill.png');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `id` int(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `age` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `guardian_name` varchar(200) NOT NULL,
  `dt` date DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`id`, `name`, `age`, `address`, `phone`, `gender`, `guardian_name`, `dt`) VALUES
(1, 'sanjana ', '20', 'J.p colony(last house) Hajipur, Vaishali', '6353150975', 'female', 'kkk sinha', '2021-07-19'),
(9, 'Krishu', '21', 'J.p colony(last house) Hajipur, Vbhi', '1234567890', 'male', 'shanker', '2021-07-19'),
(10, 'Raj', '15', 'rajedar chowk', '1236549870', 'male', 'shanker', '2021-07-19'),
(11, 'keshav', '28', 'rajedar chowk', '6353150975', 'male', 'dilip kumar', '0000-00-00'),
(14, 'g', '', '', '', '', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `patient_appointments`
--

CREATE TABLE `patient_appointments` (
  `id` int(200) NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `moblie` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `doctor_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `doctor_email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specialist` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fee` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `status` int(200) NOT NULL DEFAULT 0,
  `booking_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_upi` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_proof` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `patient_appointments`
--

INSERT INTO `patient_appointments` (`id`, `name`, `moblie`, `email`, `address`, `doctor_name`, `doctor_email`, `photo`, `specialist`, `fee`, `appointment_date`, `appointment_time`, `status`, `booking_status`, `payment_status`, `payment_upi`, `payment_proof`) VALUES
(35, 'Sanju', '6302986665', 'thamansai@gmail.com', 'shyamala Hagar guntur,AP', 'Dr.pawan', 'raj@gmail.com', 'https://images.unsplash.com/photo-1612349316228-5942a9b489c2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80', 'Child specialist', '500', '2021-07-07', '10:00:00', 1, 'pending', 'Pending', 'vamsicham@ybl', 'IMG-20210706-WA0031.jpeg'),
(37, 'thaman sai N', '6302986665', 'thamansai@gmail.com', 'shyamala Hagar guntur,AP', 'Dr.anushka', 'anushka@gmail.com', 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80', 'Eye', '500', '2021-07-07', '10:00:00', 1, 'pending', 'Success', 'vamsicham@oksbi', 'IMG-20210706-WA0017.jpeg'),
(38, 'thaman sai N', '6302986665', 'thamansai@gmail.com', 'shyamala Hagar guntur,AP', 'Dr.keerthi', 'keerthi@gmail.com', 'https://images.unsplash.com/photo-1591604021695-0c69b7c05981?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80', 'Neurology', '500', '2021-07-07', '10:00:00', 0, 'pending', 'pending', 'not paid', 'not uploaded'),
(39, 'thaman sai N', '6302986665', 'thamansai@gmail.com', 'shyamala Hagar guntur,AP', 'Dr.pawan', 'pawan@gmail.com', 'https://images.unsplash.com/photo-1612349316228-5942a9b489c2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80', 'Child specialist', '500', '2021-07-15', '14:00:00', 0, 'pending', 'Success,not verified', 'vamsicham@paytm', 'IMG_20210706_144925.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `payments_upi`
--

CREATE TABLE `payments_upi` (
  `phone_pay` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `google_pay` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paytm` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments_upi`
--

INSERT INTO `payments_upi` (`phone_pay`, `google_pay`, `paytm`) VALUES
('vamsicham@ybl', 'vamsicham@oksbi', 'vamsicham@paytm');

-- --------------------------------------------------------

--
-- Table structure for table `specialization`
--

CREATE TABLE `specialization` (
  `id` int(200) NOT NULL,
  `specialization` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `specialization`
--

INSERT INTO `specialization` (`id`, `specialization`) VALUES
(1, 'Medicine Specialist'),
(2, 'Child Specialist'),
(3, 'Bone And Joints'),
(4, 'Dentist'),
(5, 'Urologist'),
(6, 'Skin and Hair'),
(7, 'Eye'),
(8, 'Cardiologist'),
(9, 'Neurology'),
(10, 'Orthopedic'),
(12, 'chiropractor');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `moblie` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `moblie`, `email`, `password`, `address`) VALUES
(20210002, 'umesh sir', '6302986667', 'karthik@gmail.com', 'vamsicham', 'J.p colony(last house) Hajipur, bhihar'),
(20210004, 'sanju', '9876543210', 'kalyan@gmail.com', 'vamsicham', '7-6-846/80'),
(20210006, 'thaman sai N', '6302986665', 'thamansai@gmail.com', 'vamsicham', 'shyamala Hagar guntur,AP'),
(20210007, 'thaman', '6302986669', 'thaman@gmail.com', 'vamsicham', 'kudg hhf '),
(20210008, 'thaman', '6302986671', 'thaman@gmail.com', 'vamsicham', 'kudg hhf '),
(20210009, 'thaman', '6302986672', 'thaman@gmail.com', 'vamsicham', 'kudg hhf '),
(20210010, 'thaman', '6302986673', 'thaman@gmail.com', 'vamsicham', 'kudg hhf '),
(20210018, 'himqnwhu', '1234567892', 'vamstyhi@gmail.com', 'karthikgui', 'fjb GH HTC '),
(20210020, 'vamsi', '9666228101', 'vansi@gmail.com', 'chamsamvi', 'nks sika sijaib'),
(20210021, 'karthik', '9123456780', 'vamsi@gmail.com', 'vamsicham', 'no address'),
(20210022, 'vamsi', '6302123456', 'vamsi@gmail.xom', 'chamsamvi', 'vamsi'),
(20210023, 'umesh', '9381387116', 'sanjay@gmail.com', 'vamsicham', 'ball ska Mao u'),
(20210024, 'karthil', '8520812730', 'pikki@gmail.com', 'vamsicham', 'no add'),
(20210025, 'nani', '6303236101', 'sanjsu@gmail.com', 'vamsicham', 'no add'),
(20210026, 'vamai', '1472583690', 'nktg kyvb', 'vamsicham', 'hjibju'),
(20210027, 'naik', '9638527410', 'naik@gmail.com', 'vamsicham', 'no add'),
(20210028, 'qwerty', '0123456789', 'bk j', 'vamsicham', 'vau h'),
(20210029, 'mukesh kumar', '9162105018', 'mukesh@gmail.com', '123456', 'Bhagalpur'),
(20210031, 'Krishu', '6353157069', 'krishu@gmail.com', '123456', 'J.p colony(last house) Hajipur, Vais');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `header`
--
ALTER TABLE `header`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `header1`
--
ALTER TABLE `header1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient_appointments`
--
ALTER TABLE `patient_appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specialization`
--
ALTER TABLE `specialization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `header`
--
ALTER TABLE `header`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `header1`
--
ALTER TABLE `header1`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `patient_appointments`
--
ALTER TABLE `patient_appointments`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `specialization`
--
ALTER TABLE `specialization`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20210032;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
