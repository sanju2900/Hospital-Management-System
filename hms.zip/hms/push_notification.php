<?php
include("auth_session.php");
include "header.php";
include "connection.php";
?>

<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script>
  window.OneSignal = window.OneSignal || [];
  OneSignal.push(function() {
    OneSignal.init({
      //appId: "69a71f80-6fa7-411a-b967-d45d9aca28ca",
        appId: "aa94f279-2ca4-4491-8213-0c0cec1f1e16",
    });
  });
</script>
  
  <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><b><i>Welcome!!! List of Test Lab Organization</i></b></h1>
                    </div>
                </div>
            </div>
         <!--  <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Dashboard</a></li>
                            <li><a href="#">Table</a></li>
                            <li class="active">Data table</li>
                        </ol>
                    </div>
                </div>
            </div>-->
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                        <h3>Send Push Notification</h3>
                        <div class="form-group form-group-area">
                            <label class="form-title"> Title</label>
                            <input type="text" class="form-control" id="PUSH_title" placeholder="eg: Welcome">
                        </div>
                        <div class="form-group form-group-area">
                            <label class="form-title">Message</label>
                            <textarea class='form-control' id="PUSH_message"
                                style="height:300px; width:100%;padding:10px;">

                                    </textarea>
                        </div>
                        <div class="input-group form-group-area" id="bannerarea">
                            <label class="form-title">Banner</label>
                            <input type="file" class="form-control" id="PUSH_banner">
                            <div class="input-group-append">
                                <button class="btn btn-sm btn-outline-primary" onclick="uploadPushBanner();">Upload</button>
                            </div>
                        </div>
                        <div class="form-group form-group-area">
                            <label class="form-title"> Target URL(Optional)</label>
                            <input type="text" class="form-control" id="PUSH_url">
                        </div>

                        <div class="form-group form-group-area">
                            <center>
                                <button onclick="pushNotification();" class="btn btn-primary">Send Message</button>
                            </center>
                        </div>
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


    </div><!-- /#right-panel -->

    <!-- Right Panel -->


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" 
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="vendors/jszip/dist/jszip.min.js"></script>
    <script src="vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <script src="assets/js/init-scripts/data-table/datatables-init.js"></script>
    <script src="js/ajaxlogic.js"></script>


</body>

</html>
