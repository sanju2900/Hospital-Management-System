<?php
include("auth_session.php");
include "header.php";
?>
  
  <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
       
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                        <!--    <div class="card-header">
                                <strong class="card-title">Credit Card</strong>
                            </div>-->
                            <div class="card-body">
                                <!-- Credit Card -->
                               


                            </div>
                        </div> <!-- .card -->

                    </div>
                    <!--/.col-->

                                             </div>
                                        </div><!-- .animated -->
                                    </div><!-- .content -->
<?php
include "footer.php";
    /*
$tm=md5(time());//make image name unquie

$fnm1=$_FILES["photo"] ["name"];
$dst1="./upload/".$tm.$fnm1;
$dst_db1="upload/".$tm.$fnm1;
move_uploaded_file($_FILES["photo"]["tmp_name"],$dst1); 
*/
/*
$email = $_POST['email'];
$password = $_POST['password'];

$errors = array();

$e = "SELECT email FROM doctor WHERE email='$email'";
$ee =mysqli_query($link,$e);

if (empty($email))
{
    $errors['e'] ="Email required";
}else if(mysqli_num_rows($ee) > 0)
{
    $errors['e'] = "Email exist";
}
if (empty($password))
{
    $errors['p'] ="Password required";
}

if(count($errors)==0)
{
    $result=mysqli_query($link,"insert into doctor value(NULL,'$_POST[doctor_name]','$_POST[specialist]','$_POST[email]','$_POST[phone]','$_POST[password]','$_POST[fee]','$_POST[location]','$_POST[status]','$_POST[activity]','$_POST[photo]')") or die(mysqli_error($link));
    if($result)
    {
       echo "<script>alert('done')</script>";
    }
    else
    {
        echo "<script>alert('Failed')</script>";
    }
}
*/

/*

mysqli_query($link,"insert into doctor value(NULL,'$_POST[doctor_name]','$_POST[specialist]','$_POST[email]','$_POST[phone]','$_POST[password]','$_POST[fee]','$_POST[location]','$_POST[status]','$_POST[activity]','$_POST[photo]')") or die(mysqli_error($link));

 ?>
        <script type="text/javascript">
          alert("Doctor added successfully");
          window.location.href=window.location.href;
        </script>
        <?php
  */

?>