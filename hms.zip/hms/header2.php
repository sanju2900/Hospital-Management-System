<?php
//include("auth_session.php");
 include "connection.php";
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dashboard</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>
<style>
  
    .menu-icon{
        color:black;
        margin-left:5px;
        padding-left:5px;
    }
.menu-bg{
    color:black;
    background-color:white;
    border-radius:5px;
    width:100%;
}
.menu-bg:hover{
    color:white;
    background-color:blue;
    border-radius:5px;
    width:100%;
}
</style>

<body>
    <!-- Left Panel
<php $page= basename($_SERVER['PHP_SELF']);?> -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default" >
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center"style="background-color:white;">
       <!-- <a class="navbar-brand brand-logo mr-5" href="dashboard.php"><img src="images/logo.svg" class="mr-2" alt="logo"/></a>
   <a class="navbar-brand brand-logo-mini" href="index.html"><img src="images/logo-mini.svg" alt="logo"/></a>
   <a class="navbar-brand brand-logo mr-5" href="applist1.php"><img src="images/doc.png" class="mr-2" alt="logo" width="100"/></a>-->
   <a class="navbar-brand brand-logo mr-5" href="dashboard.php"><img src="images/doc1.png"  class="mr-2" alt="logo"/></a>

      </div>
            <div class="navbar-header" >
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
             <!--   <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end" style="color:black">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="icon-menu"></span>
        </button>-->

             <!--    <a class="navbar-brand" href="./"><img src="images/d1logo.png" alt="Logo"></a>
               <a class="navbar-brand hidden" href="./"><img src="images/login.png" alt="Logo"></a>-->
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse" style="color:black">
                <ul class="nav navbar-nav">
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="applist1.php"> <i class="menu-icon fa fa-dashboard" style="color:black"></i>Dashboard </a>
                    </li>
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="doctorlist1.php"> <i class="menu-icon fa fa-stethoscope" style="color:black"></i>Doctor List </a>
                    </li>
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="applist2.php"> <i class="menu-icon fa fa-group (alias)" style="color:black"></i>Appointment List </a>
                    </li>
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="register.php"> <i class="menu-icon fa  fa-plus-square" style="color:black"></i>Add Patient </a>
                    </li>
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="patientlist.php"> <i class="menu-icon fa fa-user" style="color:black"></i>Patients List </a>
                    </li>
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="transaction.php"> <i class="menu-icon fa  fa-money" style="color:black"></i>Transaction List</a>
                    </li>
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="bill.php"> <i class="menu-icon fa  fa-print" style="color:black"></i>Generate Bill</a>
                    </li>
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="prescription.php"> <i class="menu-icon fa  fa-medkit" style="color:black"></i>Prescription</a>
                    </li>
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="upload_header.php"> <i class="menu-icon fa  fa-toggle-up (alias)" style="color:black"></i>Upload Header</a>
                    </li>
                    
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="help1.php"> <i class="menu-icon fa  fa-gears (alias)" style="color:black"></i>Help & Support</a>
                    </li>
                  
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="logout1.php"> <i class="menu-icon fa  fa-power-off" style="color:black"></i>Logout</a>
                    </li>
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

              
                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           <!-- <img class="user-avatar rounded-circle" src="images/admin.jpg" alt="User Avatar">-->
                           <h2>DOCTOR PANAL</h2>
                        </a>

                        <div class="user-menu dropdown-menu">

                            <a class="nav-link" href="logout1.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>



                </div>
            </div>

        </header><!-- /header -->
        <!-- Header-->
