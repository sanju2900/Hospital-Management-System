<?php
include("auth_session.php");
include "header.php";
include "connection.php";
?>
  
  <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><b><i>Welcome!!! To Doctor List</i></b></h1>
                    </div>
                </div>
            </div>
        
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Doctor Data Table</strong>
                            </div>
                            <div class="col-md-9" style="overflow-x: auto">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Name</th>
                                            <th>Specialization</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Password</th>
                                            <th>Fee</th>
                                            <th>Address</th>
                                            <th>Activity</th>
                                            <th>Status</th>
                                           
                                            <th>Photo</th>
                                            <th>Edit</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        $time =time();
                                        $count=0;
                                        $res=mysqli_query($link,"select * from doctor");
                                        while($row=mysqli_fetch_assoc($res))
                                        {
                                           if($row["status"]=="online"){
                                               $class="btn-success";
                                               $status="online";
                                           }else{
                                               $class="btn-danger";
                                               $status="offline";
                                           }
                                            
                                          
                                          $count=$count+1;                      
                                            ?>
                                                <tr>
                                            <th scope="row"><?php echo $count; ?></th>
                                            <td><?php echo $row["doctor_name"]?></td>
                                            <td><?php echo $row["specialist"]?></td>
                                            <td><?php echo $row["email"]?></td>
                                            <td><?php echo $row["phone"]?></td>
                                            <td><?php echo $row["password"]?></td>
                                            <td><?php echo $row["fee"]?></td>
                                            <td><?php echo $row["location"]?></td>

                                            <td><?php echo $row["activity"]?></td>

                                          <!--  <td><label class="switch switch-text switch-success switch-pill">
                                                <input type="checkbox" class="switch-input" checked="true"> <span data-on="<php echo $row["activity"]?>" data-off="<php echo $row["activity"]?>" class="switch-label"></span> 
                                                <span class="switch-handle"></span></label></td>-->
                                                
                                                <td><button type="button" class="btn <?php echo $class ?>"><?php echo $status?></button></td>
                                                

                                            <td><img src="<?php echo $row["photo"];?>" height="50" width="50"></td>
                                            <td><a class="btn btn-success" href="edit_doctor.php?id=<?php echo $row["id"]; ?>">Edit</a></td>
                                          <!--  <td><a class="btn btn-danger" href="delete.php?id=<php echo $row["id"]; ?>">Delete</a></td>-->
                                        </tr>

                                            <?php
                                        }
                                        
                                        ?>

                                      
                             
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


    </div><!-- /#right-panel -->

<!-- status of doctor -->

<script>
function updateUserStatus()
{
    jQuery.ajax({
        url:'update_user_satus.php';
        success:function()
        {

        }
    });
}
//automatically run
setInterval(function(){
    updateUserStatus();
}, 5000);
</script>


    <!-- Right Panel -->


    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="vendors/jszip/dist/jszip.min.js"></script>
    <script src="vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <script src="assets/js/init-scripts/data-table/datatables-init.js"></script>


</body>

</html>
