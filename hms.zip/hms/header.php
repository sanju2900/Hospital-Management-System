<?php
 include "connection.php";
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dashboard</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>
<style>
  
    .menu-icon{
        color:black;
        margin-left:5px;
        padding-left:5px;
    }
.menu-bg{
    color:black;
    background-color:white;
    border-radius:5px;
    width:100%;
}
.menu-bg:hover{
    color:white;
    background-color:blue;
    border-radius:5px;
    width:100%;
}
</style>

<body>
    <!-- Left Panel
<php $page= basename($_SERVER['PHP_SELF']);?> -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default" >
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center"style="background-color:white;">

        <a class="navbar-brand brand-logo mr-5" href="dashboard.php"><img src="images/logo23.png"  class="mr-2" alt="logo"/></a>

       <!-- <a class="navbar-brand brand-logo mr-5" href="dashboard.php"><img src="images/logo.svg" class="mr-2" alt="logo"/></a>
   <a class="navbar-brand brand-logo-mini" href="index.html"><img src="images/logo-mini.svg" alt="logo"/></a>-->
      </div>
            <div class="navbar-header" >
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
             <!--   <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end" style="color:black">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="icon-menu"></span>
        </button>-->

             <!--    <a class="navbar-brand" href="./"><img src="images/d1logo.png" alt="Logo"></a>
               <a class="navbar-brand hidden" href="./"><img src="images/login.png" alt="Logo"></a>-->
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse" style="color:black">
                <ul class="nav navbar-nav">
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard" style="color:black"></i>Dashboard </a>
                    </li>
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="doctorlist.php"> <i class="menu-icon fa fa-stethoscope" style="color:black"></i>Doctor List </a>
                    </li>
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="patient.php"> <i class="menu-icon fa  fa-user-md" style="color:black"></i>Patient History </a>
                    </li>
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="applist.php"> <i class="menu-icon fa fa-group (alias)" style="color:black"></i>Appointment Details </a>
                    </li>
                 <!--   <li class="menu-bg"style=margin-top:5px;>
                        <a href="#"> <i class="menu-icon fa fa-medkit" style="color:black"></i>Prescription List </a>
                    </li>-->
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="doctor.php"> <i class="menu-icon fa  fa-plus-square" style="color:black"></i>Add Doctor </a>
                    </li>
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="specialization.php"> <i class="menu-icon fa ti-briefcase" style="color:black"></i>Add Specialization</a>
                    </li>
                   <li class="menu-bg"style=margin-top:5px;>
                        <a href="push_notification.php"> <i class="menu-icon fa   fa-question-circle" style="color:black"></i>Push Notification </a>
                    </li>
					<li class="menu-bg"style=margin-top:5px;>
                        <a href="changepassword.php"> <i class="menu-icon fa   fa-user" style="color:black"></i>Change Password </a>
                    </li>
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="delete_doc1.php"> <i class="menu-icon fa   fa-trash-o" style="color:black"></i>Delete Doctor </a>
                    </li>
                    
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="help.php"> <i class="menu-icon fa  fa-gears (alias)" style="color:black"></i>Help & Support</a>
                    </li>
                    <li class="menu-bg"style=margin-top:5px;>
                        <a href="logout.php"> <i class="menu-icon fa  fa-power-off" style="color:black"></i>Logout</a>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left mr-sm-6" style="background-color:white">
                        <button class="search-trigger"><i class="fa fa-search"></i></button>
                        <div class="form-inline">
                            <form class="search-form" style="background-color:white">
                                <input class="form-control mr-sm-2"  type="text" placeholder="Search ..." aria-label="Search">
                                <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
                            </form>
                        </div>
<?php 
//$count=0;
$sql_get = mysqli_query($link,"SELECT * FROM patient_appointments WHERE status=0");
$coun = mysqli_num_rows($sql_get);
?>

                        <div class="dropdown for-notification">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="notification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-bell"></i>
                                <span class="count bg-danger" id="count"><?php echo $coun;?></span>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="notification">
                                <p class="red">You have <?php echo $coun;?> Notification</p>
                                <?php
                                $sql_get1 = mysqli_query($link,"SELECT * FROM patient_appointments WHERE status=0");
                                if(mysqli_num_rows($sql_get1)>0)
                                {
                                    while($result = mysqli_fetch_assoc($sql_get1))
                                    {
                                        echo '<a class="dropdown-item media bg-flat-color-1 text-black font-weight-bold" href="applist.php?id='.$result['id'].'">
                                        <i class="fa fa-check"></i>
                                       '.$result['name'].'
                                    </a>';
                                    echo '<div class="dropdown divider"></div>';
                                    }
                                }else
                                {
                                    echo '<a class="dropdown-item media bg-flat-color-1 text-danger font-weight-bold" href="#">
                                    <i class="fa fa-frown-o"></i>
                                    <p><b>Sorry no masseges!!!</b></p>
                                </a>';
                                }
                                ?>
                                
                              
                            </div>
                        </div>

                        
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="#"><i class="fa fa-user"></i> My Profile</a>
                            

                            <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                        </div>
                    </div>



                </div>
            </div>

        </header><!-- /header -->
        <!-- Header-->
