 
   <?php
   include("auth_session1.php");
         include("header2.php");
         include("connection.php");

        $id=$_GET["id"];
         $res=mysqli_query($link,"select * from patient_appointments where id=$id");
         while($row=mysqli_fetch_array($res))
         {
             $payment_status=$row["payment_status"];
            
         }

    ?>



        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Update payment_status</h1>
                    </div>
                </div>
            </div>
                </div>

        <div class="content mt-3">
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <form name="form1" action="" method="post">
                            <div class="card-body">
                                <!-- Credit Card -->
                                
                                <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Update payment_status</strong></div>
                            <div class="card-body card-block">
                                        <div class="form-group"><label for="vat" class=" form-control-label">payment_status</label><select name="payment_status" value="<?php echo $payment_status;?>" class="form-control">
                                     <option value="Success">Success</option>
                                     <option value="Success,not verified ">Success,Not verified</option>
                                     <option value="Pending">Pending</option>
                                        </select></div>
                                      
                                        <div class="form-group">
                                        <input type="submit" name="submit1" class="btn btn-success" value="Update payment_status">
                                        </div>

                                         </div>
                                 </div>
                           </div>

                            
                    </div>
                    </form>



                        </div> <!-- .card -->

                    </div>
                    <!--/.col-->

                
                
                
                </div>
                                        </div><!-- .animated -->
                                    </div><!-- .content -->

  <?php
if(isset($_POST['submit1']))
{
    mysqli_query($link,"update patient_appointments set payment_status='$_POST[payment_status]' where id=$id") or die(mysqli_error($link));
    ?>
    <script type="text/javascript">
     alert("edited");
      window.location="transaction.php";
    </script>
    <?php

}
?>




        <?php
         include("footer.php");
         ?>
 