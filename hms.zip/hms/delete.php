<?php
include("auth_session.php");     
include("connection.php");

$id=$_GET["id"];
mysqli_query($link,"delete from user where id=$id");
?>

<script type="text/javascript">
alert("Patients Deleted successfully");
window.location="patient.php";
</script>
