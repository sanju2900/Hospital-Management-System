<?php
include("auth_session1.php");

include "connection.php";
?>
  
  <html>
<head>
  <title>BILL</title>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="print.css" media="print">
</head>
<style>
.table td, .table th {
        font-size: 20px;
    }

footer{
   
   color: rgb(169, 169, 169);
  
   margin-bottom: 5px;   
 position: fixed;
 left: 0;
 bottom: 0;
 width: 100%;


 text-align: center;

}

</style>

  <div class="breadcrumbs">
            
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                              <!--  <strong class="card-title"><img src="images/print.png" style="height:200;width:1200;"></strong>-->                              
                              <strong class="card-title">
                                <?php
                                $res=mysqli_query($link,"select * from header1");
                                while($row=mysqli_fetch_assoc($res))
                                {
                                    ?>
                                   <img src="<?php echo $row["bill_photo"];?>" height="200" width="1200">

                                    <?php
                                }
                                ?>
                            
                            </strong>
                            
                            </div>
							<div class="col-md-9">
                                <table type="hidden" id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Bill Number</th>
                                            <th>Patient Name</th>
                                            <th>Date</th>
                                        </tr>
                                        <?php
                                                $id=$_GET["id"];  
                                            $sqlCheckEmail = "(SELECT * FROM patient WHERE id='$id')";
                                          // $sqlCheckEmail = "(SELECT * FROM patient)";
                                         $res=mysqli_query($link,$sqlCheckEmail);
                                               while($row=mysqli_fetch_array($res))
                                            {
                                               // $count=$count+1;
                                                                 
                                                ?>
                                                    <tr>
                                                    <th><?php echo $row["id"]; ?></th>

                                                
                                                <td><?php echo $row["name"]?></td>
                                                
                                                <td><?php echo $row["dt"]?></td></tr>
                                                <?php
                                            }
                                            ?>
                                        <tr>
                                        <th>Giardian Name</th>
                                            <th>Patient Age</th>
                                            <th>Gender</th></tr>
                                            <?php
                                        $id=$_GET["id"];
                                            $sqlCheckEmail = "(SELECT * FROM patient WHERE id='$id')";
                                          // $sqlCheckEmail = "(SELECT * FROM patient)";
                                         $res=mysqli_query($link,$sqlCheckEmail);
                                               while($row=mysqli_fetch_array($res))
                                            {
                                                                 
                                                ?>
                                                    <tr>
                                                
                                                
                                               
                                                <td><?php echo $row["guardian_name"]?></td>

                                                <td><?php echo $row["age"]?></td>
                                                <td><?php echo $row["gender"]?></td></tr>
                                                <?php
                                            }
                                            ?>

<tr>
                                                
                                                <td><p><div class="form-group col-lg-12">
                                                <label>Fee</label>

                                                <input type="number" name="name" placeholder="Amount">
                                                </div></p></td>
                                                <td><p><div class="form-group col-lg-12">
                                                <label>Emergency Amount</label>

                                                <input type="number" name="name" placeholder="Emergency Amount">
                                                </div></p></td>
                                                <td><p><div class="form-group col-lg-12">
                                                <label>Total</label>
                                                <input type="number" name="name" placeholder="TOtal">
                                                </div></p></td>
            
                                            </tr>

                             
                                    </tbody>
                                </table>
                                <div class="text-center">
                            <button onclick="window.print();" class="btn btn-primary" id="print-btn">Print</button>
                        </div>
                        

                                </div>
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


    </div><!-- /#right-panel -->

    <!-- Right Panel -->


  
    <footer>
  
  <p><div class="form-group col-lg-12">

<input type="text" name="name" placeholder="Name of Doctor/Manager">
</div></p>
</footer>    

    
</body>

</html>
