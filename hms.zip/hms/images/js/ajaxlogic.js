function updateDoctorActivity(status, id){
    if(status=="checked"){
       
        invokeUpdateActivity("off", id);
    }else{
        invokeUpdateActivity("on", id);
    }
};



function invokeUpdateActivity(st, did){
    $.ajax({
        url: "updateDoctorActivity.php",
        cache: false,
        data:{
            id:did,
            activity:st,
        },
        type: 'POST',
        success: function(dataResult) {
            res = JSON.parse(dataResult);
            if(res=="success"){
                alert("Activity Updated Successfully");
                window.location="applist1.php";
            }else{
                alert("Activity not updated due to error");
            }
        }
    });
}