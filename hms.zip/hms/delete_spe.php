<?php
include("auth_session.php");     
include("connection.php");

$id=$_GET["id"];
mysqli_query($link,"delete from specialization where id=$id");
?>

<script type="text/javascript">
alert("specialization Deleted successfully");
window.location="specialization_list.php";
</script>
