<?php
include("auth_session1.php");     
include("connection.php");

$id=$_GET["id"];
mysqli_query($link,"delete from patient where id=$id");
?>

<script type="text/javascript">
alert("Patient Deleted successfully");
window.location="patientlist.php";
</script>
