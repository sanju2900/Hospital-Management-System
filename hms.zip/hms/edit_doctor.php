 
   <?php
   include("auth_session.php");
         include("header.php");
         include("connection.php");

        $id=$_GET["id"];
         $res=mysqli_query($link,"select * from doctor where id=$id");
         while($row=mysqli_fetch_array($res))
         {
             $name=$row["doctor_name"];
             $spe=$row["specialist"];
             $email=$row["email"];
             $phone=$row["phone"];
             $password=$row["password"];
             $fee=$row["fee"];
             $address=$row["location"];
            
         }

    ?>



        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Update Doctor</h1>
                    </div>
                </div>
            </div>
                </div>

        <div class="content mt-3">
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <form name="form1" action="" method="post">
                            <div class="card-body">
                                <!-- Credit Card -->
                                
                                <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Update Doctor</strong></div>
                            <div class="card-body card-block">
                            <div class="form-group"><label for="company" class=" form-control-label">Name</label><input type="text" name="doctor_name" value="<?php echo $name;?>" placeholder="Name" class="form-control"></div>
                                    <div class="form-group"><label for="vat" class=" form-control-label">Specialization</label><select  name="specialist" value="<?php echo $spe;?>" class="form-control">
                                    <option>Medicine Specialist</option>
                                        <option>Child Specialist</option>
                                        <option>Bone And Joints</option>
                                        <option>Dentist</option>
                                        <option>Urologist</option>
                                        <option>Skin and Hair</option>
                                        <option>Eye</option>
                                        <option>Cardiologist</option>
                                        <option>Neurology</option>
                                        <option>Orthopedic</option>

                                        </select>
                                    </div>
                                        <div class="form-group"><label for="street" class=" form-control-label">Email</label><input type="email" name="email" value="<?php echo $email;?>" placeholder="Email" class="form-control"></div>
                                        <div class="form-group"><label for="street" class=" form-control-label">Contact</label><input type="number" name="phone" value="<?php echo $phone;?>" placeholder="Phone Number" class="form-control"></div>
                                            <div class="form-group"><label for="street" class=" form-control-label">Password</label><input type="password" name="password" value="<?php echo $password;?>" placeholder="Password" class="form-control"></div>
                                            <div class="form-group"><label for="street" class=" form-control-label">Fee(In Rupee)</label><input type="number" name="fee" value="<?php echo $fee;?>" placeholder="fee" class="form-control"></div>
                                            <div class="form-group"><label for="street" class=" form-control-label">Address</label><input type="text" name="location" value="<?php echo $address;?>" placeholder="Address" class="form-control"></div>



                                        <div class="form-group">
                                        <input type="submit" name="submit1" class="btn btn-success" value="Update Doctor">
                                        </div>

                                         </div>
                                 </div>
                           </div>

                            
                    </div>
                    </form>



                        </div> <!-- .card -->

                    </div>
                    <!--/.col-->

                
                
                
                </div>
                                        </div><!-- .animated -->
                                    </div><!-- .content -->

  <?php
if(isset($_POST['submit1']))
{
    mysqli_query($link,"update doctor set doctor_name='$_POST[doctor_name]',specialist='$_POST[specialist]',email='$_POST[email]',phone='$_POST[phone]',password='$_POST[password]',fee='$_POST[fee]',location='$_POST[location]' where id=$id") or die(mysqli_error($link));
    ?>
    <script type="text/javascript">
     
      window.location="doctorlist.php";
    </script>
    <?php

}
?>




        <?php
         include("footer.php");
         ?>
 