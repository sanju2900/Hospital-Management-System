<?php include("auth_session.php"); ?>
<?php

	 include("header.php");
	 include("connection.php");
	 
?>



        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Add Doctor</h1>
                    </div>
                </div>
            </div>
                </div>

        <div class="content mt-3">
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <form name="abc" action="" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
                            <div class="card-body">
                                <!-- Credit Card -->
                                
                                <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header"><strong>Add Doctor</strong></div>
                            <div class="card-body card-block">
                                <div class="form-group"><label for="company" class=" form-control-label">Doctor Name</label><input type="text" name="doctor_name" placeholder="Enter Name" class="form-control"></div>
                                    <div class="form-group"><label for="vat" class=" form-control-label">Specialization</label><select name="specialist" placeholder="You job field" class="form-control">
                                    
                                    <?php
                                    $sql="SELECT * FROM specialization";
                            $res=mysqli_query($link,$sql);
                            while($row=mysqli_fetch_array($res))
                            {
                                ?>
                                <option value="<?php echo $row["id"];?>"><?php echo $row["specialization"];?></option>
                                <?php
                            }

                            ?>
                                  
                                  </select>
                                    </div>
                                        <div class="form-group"><label for="street" class=" form-control-label">Email</label><input type="email" name="email" placeholder="Email" class="form-control" required>
                                  
                                    </div>
                                        <div class="form-group"><label for="street" class=" form-control-label">Contact</label><input type="number" name="phone" placeholder="Phone number" class="form-control"></div>
                                        <div class="form-group"><label for="street" class=" form-control-label">Qualification</label><input type="text" name="qualification" placeholder="MBBS, MD, or Anything" class="form-control"></div>

                                        <div class="form-group"><label for="street" class=" form-control-label">Password</label><input type="password" name="password" placeholder="password" class="form-control" required>
                                      </div>
                                        <div class="form-group"><label for="street" class=" form-control-label">Fee(In Rupee)</label><input type="number" name="fee" placeholder="fee in rupee and only number" class="form-control"></div>
                                        <div class="form-group"><label for="street" class=" form-control-label">Address</label><input type="text" name="location" placeholder="place" class="form-control"></div>
                                        <div class="form-group"><label for="street" class=" form-control-label">status</label><select  name="status" placeholder="place" class="form-control">
                                       
                                        <option value="offline">Offline</option> 
                                        <option value="Online">Online</option>
                                        </select></div>
                                        <div class="form-group"><label for="street" class=" form-control-label">Activity</label><select name="activity" placeholder="place" class="form-control">
                                        
                                        <option value="off">Off</option>
                                        <option value="On">On</option>
                                        </select>
                                        </div>

                                      <!--  <div class="form-group"><label for="street" class=" form-control-label">Photo</label><input type="url" name="photo" placeholder="url/drive link" id="myFile"></div>
-->
                                        <div class="form-group"><label for="street" class=" form-control-label">Photo</label><input type="file" name="photo" id="myFile"></div>
                                        <div class="form-group">
                                        <input type="submit" name="submit1" class="btn btn-success" value="Add Doctor">
                                        </div>

                                                </div>
                                           </div>
                           </div>

                            
                        </form>



                        </div> <!-- .card -->

                    </div>
                    <!--/.col-->

                
                
                
                </div>
            </div><!-- .animated -->
                                    </div><!-- .content -->

  <?php
if(isset($_POST['submit1']))
{
    
  $img_loc = $_FILES['photo']['tmp_name'];
  //same name se upload krna
  $img_name=$_FILES['photo']['name'];
//uder ke naame se image upload hoga
  $uname=$_POST['doctor_name'];
  //imag ke ext. ke liye
  $img_ext=pathinfo($img_name,PATHINFO_EXTENSION);

  $img_size=$_FILES['photo']['size']/(1024*1024);
//img path
$img_des="upload/".$uname.".".$img_ext;

if(($img_ext!='jpg') && ($img_ext!='png') && ($img_ext!='jpeg'))
{
    echo ' <script type="text/javascript">
    alert("Invalid image Extension");
    window.location.href=window.location.href;
  </script>';
  exit();
}

if($img_size>1)
{
    echo ' <script type="text/javascript">
    alert("Image size is greater than 1MB");
    window.location.href=window.location.href;
  </script>';
}


 $res= mysqli_query($link,"insert into doctor value(NULL,'$uname','$_POST[specialist]','$_POST[email]','$_POST[phone]','$_POST[qualification]','$_POST[password]','$_POST[fee]','$_POST[location]','$_POST[status]','$_POST[activity]','$img_des')") or die(mysqli_error($link));
if($res)
{
    move_uploaded_file($img_loc,$img_des);  
    echo ' <script type="text/javascript">
    alert("Doctor added successfully");
    window.location.href=window.location.href;
  </script>';
}
else
{
    echo ' <script type="text/javascript">
    alert("Doctor added Failed");
    window.location.href=window.location.href;
  </script>';
}

}
?>




        <?php
         include("footer.php");
         ?>
 


 <script>
function validateForm()
{
    var doctor_name=document.forms["abc"]["doctor_name"].value;
    var re=/^[a-zA-Z]{2,10}$/;
    if(!re.test(doctor_name))
    {
    alert("invalid doctor_name...doctor_name must be between 2 to 10 characters");
    document.forms["abc"]["doctor_name"].focus();
    return false;
    }

 
    var email=document.forms["abc"]["email"].value;
    var re1=/^([a-zA-Z0-9]{2,10})@([a-zA-Z]+)\.([a-zA-Z]{3})$/;
    if(!re1.test(email))
    {
    alert("invalid email");
    document.forms["abc"]["email"].focus();
    return false; 
    }
   
    var phone=document.forms["abc"]["phone"].value;
    var re2=/^([6-9]{1})([0-9]{9})$/;
    if(!re2.test(phone))
    {
    alert("invalid Mobile number,should have 10 digit and starting no. be 6-9");
    document.forms["abc"]["phone"].focus();
    return false;
    }


    var location=document.forms["abc"]["location"].value;
    var re=/^[a-zA-Z]{2,100}$/;
    if(!re.test(location))
    {
    alert("invalid location...location must be between 2 to 100 characters");
    document.forms["abc"]["location"].focus();
    return false;
    }

    
    document.writeln("<b>Name:</b> "+document.abc.doctor_name.value+"<br/>"+
    "<b>Email:</b> "+document.abc.email.value+"<br/>"+
    "<b>Contact:</b> "+document.abc.phone.value+"<br/>"+
    "<b>Address:</b> "+document.abc.location.value+"<br/>"); 
    
   
}


</script>


 