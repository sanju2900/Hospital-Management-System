<?PHP
function sendMessage($title, $message, $banner, $url) {

    $heading=array(
        "en"=>$title,
    );
    $content= array(
        "en" => $message,
    );

    $fields = array(
       // 'app_id' => "69a71f80-6fa7-411a-b967-d45d9aca28ca",
       'app_id' => "aa94f279-2ca4-4491-8213-0c0cec1f1e16",
        'included_segments' => array('Subscribed Users'),
        'contents' => $content,
        'headings'=>$heading,
        'url'=>$url,
        'big_picture'=>$banner,
    );
    
    $fields = json_encode($fields);
    print($fields);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json; charset=utf-8',
        //'Authorization: Basic NTY3M2ZiYzktNzA2My00NGJhLThmNTMtZWYyNTdlMWQ2MDM4'
        'Authorization: Basic MWVhNTdhYWQtOGE4Ni00ZmVhLWJjNWUtYTliM2Q5Mzc3NzMy'
    ));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return $response;
}


if($_POST["action"]=="onesignal"){

    $title= $_POST["title"];
    $message=$_POST["message"];
    $banner=$_POST["banner"];
    $url=$_POST["url"];


    $response = sendMessage($title, $message, $banner, $url);
    $return["allresponses"] = $response;
    $return = json_encode($return);
    
    $data = json_decode($response, true);
    print_r($data);
    $id = $data['id'];
    print_r($id);
    
    print("\n\nJSON received:\n");
    print($return);
    print("\n");


}

?>